<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('detail_host.undangan', ['id' => $undangan->id])); ?>">Beranda</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('undangan.index')); ?>">Undangan</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($current); ?></li>
    </ol>
</nav>
<?php /**PATH D:\MATA KULIAH\Semester 4\PA2\New folder (2)\VMS\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>