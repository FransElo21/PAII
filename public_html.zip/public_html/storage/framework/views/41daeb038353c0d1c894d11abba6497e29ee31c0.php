

<?php $__env->startSection('content'); ?>
<style>
    .custom-span {
        font-weight: 300;
        color: #333;
        font-size: 15px;
    }

    .custom-p {
        font-size: 18px;
        color: white;
        background-color: #62D9CD;
    }

    .card {
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        border: none;
    }
</style>

<?php if(session('success_tambahdivisi')): ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil Menambahkan Divisi!',
            text: '<?php echo e(session('success_tambahdivisi')); ?>',
        });
    </script>
<?php endif; ?>

<?php if(session('success_hapusdivisi')): ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil Menghapus Divisi!',
            text: '<?php echo e(session('success_hapusdivisi')); ?>',
        });
    </script>
<?php endif; ?>

<?php if(session('success_update_divisi')): ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil Memperbarui Divisi!',
            text: '<?php echo e(session('success_update_divisi')); ?>',
        });
    </script>
<?php endif; ?>

<?php if(session('duplikat')): ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Terdapat kesalahan!',
            text: '<?php echo e(session('duplikat')); ?>',
        });
    </script>
<?php endif; ?>


<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Daftar Divisi</h4>
            <button type="button" class="btn btn-success float-start" data-toggle="modal" data-target="#tambahDivisiModal">
                <i class="fas fa-plus"></i> Tambah
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <li class="nav-item col-md-3">
                    <div class="input-group search-area">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search here...">
                        <span class="input-group-text"><a href="javascript:void(0)"><i class="flaticon-381-search-2"></i></a></span>
                    </div>
                </li>
                <br>
                <table class="table table-responsive-md" id="divisiTable">
                    <thead>
                        <tr class="custom-p">
                            <th><strong>NO.</strong></th>
                            <th><strong>Nama Divisi</strong></th>
                            <th><strong>Aksi</strong></th>
                        </tr>
                    </thead>
                    <tbody id="divisiTableBody">
                        <?php $i = 1 ?>
                        <?php $__currentLoopData = $divisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="custom-span divisi-row">
                            <td><strong><?php echo e($i++); ?></strong></td>
                            <td><?php echo e($divisi->nama_divisi); ?></td>
                            <td>
                                <div class="d-flex">
                                    <!-- Tombol Edit -->
                                    <button class="btn btn-warning shadow btn-xs sharp me-1" onclick="showEditModal(<?php echo e($divisi->id); ?>, '<?php echo e($divisi->nama_divisi); ?>')"><i class="fa fa-edit"></i></button>
                                    <!-- Tombol Hapus -->
                                    <form id="delete-form-<?php echo e($divisi->id); ?>" action="<?php echo e(route('divisi.destroy', ['id' => $divisi->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button onclick="confirmDelete(event, <?php echo e($divisi->id); ?>)" class="btn btn-danger shadow btn-xs sharp" type="submit"><i class="fa fa-trash"></i></button>
                                    </form>                                   
                                </div>                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                 <!-- Kontrol Pagination -->
                 <div class="pagination-controls">
                    <ul class="pagination"></ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Divisi -->
<div class="modal fade" id="tambahDivisiModal" tabindex="-1" role="dialog" aria-labelledby="tambahDivisiModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahDivisiModalLabel">Tambah Divisi Baru</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('divisi.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama_divisi">Nama Divisi:</label>
                        <input type="text" class="form-control" id="nama_divisi" name="nama_divisi">
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" name="submit">Tambah</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>      
        </div>
    </div>
</div>

<!-- Modal Edit Divisi -->
<div class="modal fade" id="editDivisiModal" tabindex="-1" role="dialog" aria-labelledby="editDivisiModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editDivisiModalLabel">Edit Divisi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editForm" action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group">
                        <label for="edit_nama_divisi">Nama Divisi:</label>
                        <input type="text" class="form-control" id="edit_nama_divisi" name="nama_divisi">
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Simpan</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS (Optional if you need modal functionality with JavaScript) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"></script>

<!-- SweetAlert2 for delete confirmation -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    function confirmDelete(event, divisiId) {
        event.preventDefault(); // Mencegah pengiriman formulir secara langsung

        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: 'Anda tidak akan dapat mengembalikan data ini!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + divisiId).submit(); // Mengirimkan formulir DELETE jika pengguna mengonfirmasi
            }
        });
    }

    function showEditModal(divisiId, namaDivisi) {
        document.getElementById('edit_nama_divisi').value = namaDivisi;
        document.getElementById('editForm').action = `/divisi/${divisiId}`;
        $('#editDivisiModal').modal('show');
    }

    // Fungsi pencarian
    document.getElementById('searchInput').addEventListener('keyup', function() {
        let filter = this.value.toUpperCase();
        let rows = document.querySelectorAll('#divisiTableBody .divisi-row');
        
        rows.forEach(row => {
            let text = row.innerText.toUpperCase();
            row.style.display = text.includes(filter) ? '' : 'none';
        });
    });
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function () {
        const rowsPerPage = 10;
        const rows = $('#divisiTableBody .divisi-row');
        const rowsCount = rows.length;
        const pageCount = Math.ceil(rowsCount / rowsPerPage);
        const paginationControls = $('.pagination-controls .pagination');

        function displayRows(page) {
            const start = (page - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            rows.hide();
            rows.slice(start, end).show();
        }

        function buildPagination() {
            paginationControls.empty();
            for (let i = 1; i <= pageCount; i++) {
                paginationControls.append(`<li class="page-item"><a href="#" class="page-link">${i}</a></li>`);
            }
        }

        paginationControls.on('click', 'a', function (e) {
            e.preventDefault();
            const page = $(this).text();
            displayRows(page);
            $(this).closest('li').addClass('active').siblings().removeClass('active');
        });

        // Initialize
        displayRows(1);
        buildPagination();
        paginationControls.find('li:first-child').addClass('active');
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PAII\VMS - Copy\resources\views/admin/admin_divisi.blade.php ENDPATH**/ ?>