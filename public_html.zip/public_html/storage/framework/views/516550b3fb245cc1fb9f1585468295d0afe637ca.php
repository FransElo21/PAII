

<?php $__env->startSection('content'); ?>
<?php if(session('konfirmasi_berhasil')): ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success Mengkonfirmasi Undangan!',
        text: '<?php echo e(session('success_updatehost')); ?>',
    });
</script>
<?php endif; ?>
<style>
    /* Gaya CSS tambahan di sini */
</style>
<div class="col-xl-12">
    <div class="card card-shadow">
        <div class="card-header">
            <h2 class="card-title">Konfirmasi Kunjungan</h2>
        </div>
        <div class="card-body">
            <!-- Nav tabs -->
            <div class="custom-tab-1">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#home1">Kunjungan hari ini</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="home1" role="tabpanel">
                        <div class="pt-4">
                            <?php $__currentLoopData = $undangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $undangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($undangan->status == 'Menunggu'): ?>
                                    <div class="card mb-3">
                                        <div class="card-body d-flex justify-content-between align-items-center">
                                            <div><?php echo e($undangan->pengunjung->namaLengkap); ?></div>
                                            <div><?php echo e($undangan->subject); ?></div>
                                            <div><?php echo e(\Carbon\Carbon::parse($undangan->waktu_temu)->format('d/m/Y H:i')); ?></div>
                                            <div>
                                                
                                                <a href="<?php echo e(route('detail_host.undangan', ['id' => $undangan->id])); ?>" class="btn btn-success btn-sm">Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="profile1" role="tabpanel">
                        <div class="pt-4">
                            <?php $__currentLoopData = $undangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $undangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($undangan->status == 'ditolak'): ?> <!-- Sesuaikan kondisi dengan status yang sesuai -->
                                    <div class="card mb-3">
                                        <div class="card-body d-flex justify-content-between align-items-center">
                                            <div><?php echo e($undangan->host->nama); ?></div>
                                            <div><?php echo e($undangan->subject); ?></div>
                                            <div><?php echo e($undangan->waktu_temu); ?></div>
                                            <div>
                                                <a href="<?php echo e(route('detail.undangan', $undangan->id)); ?>" class="btn btn-primary btn-sm">Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="contact1">
                        <!-- Konten untuk tab "Contact" -->
                    </div>
                    <div class="tab-pane fade" id="message1">
                        <!-- Konten untuk tab "Message" -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('host.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PAII\VMS\resources\views/host/konfirmasi_kunjungan.blade.php ENDPATH**/ ?>