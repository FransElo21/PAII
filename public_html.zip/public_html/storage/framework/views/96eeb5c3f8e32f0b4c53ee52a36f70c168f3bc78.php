<!DOCTYPE html>
<html>
<head>
    <title>Edit Host</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <style>
        body {
            background-color: #f9f9f9;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="%23B0DCE9" fill-opacity="1" d="M0,32L48,58.7C96,85,192,139,288,160C384,181,480,171,576,176C672,181,768,203,864,213.3C960,224,1056,224,1152,218.7C1248,213,1344,203,1392,197.3L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>');
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            border: 1px solid #ddd;
            border-radius: 50px;
            width: 600px;
            padding: 20px;
        }
        .form-control {
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="col-lg-12 d-flex justify-content-center">
            <div class="card">
                <div class="card-header" style="background-color: white">
                    <h4 class="card-title text-center">Ubah Data Host</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('update_host', $host->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($host->nama); ?>" placeholder="Nama" required>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo e($host->username); ?>" placeholder="Username" required>
                        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($host->alamat); ?>" placeholder="Alamat" required>
                        <input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon" value="<?php echo e($host->nomor_telepon); ?>" placeholder="Nomor Telepon" required>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($host->email); ?>" placeholder="Email" required>
                        <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" value="<?php echo e($host->jenis_kelamin); ?>" placeholder="Jenis Kelamin" required>
                        <select class="form-control" id="divisi" name="divisi" required>
                            <option value="">Pilih Divisi</option>
                            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($division->id); ?>" <?php echo e($host->divisi_id == $division->id ? 'selected' : ''); ?>><?php echo e($division->nama_divisi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        
                        <select class="form-control" id="lokasi" name="lokasi" required>
                            <option value="">Pilih Lokasi</option>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location->id); ?>" <?php echo e($host->lokasi_id == $location->id ? 'selected' : ''); ?>><?php echo e($location->ruangan); ?> <?php echo e($location->lantai); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                        
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="foto_profil" name="foto_profil" accept="image/*">
                            <label class="custom-file-label" for="foto_profil">Pilih Foto Profile</label>
                          </div>
                        <button type="submit" class="btn btn-success btn-block mt-3" style="border-radius: 20px">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script>
        // Mengubah teks label sesuai nama file yang dipilih
        document.getElementById('foto_profil').addEventListener('change', function() {
          var fileName = this.files[0].name;
          var nextSibling = this.nextElementSibling;
          nextSibling.innerText = fileName;
        });
      </script>
</body>
</html>
<?php /**PATH D:\PAII\VMS\resources\views/admin/edit_host.blade.php ENDPATH**/ ?>