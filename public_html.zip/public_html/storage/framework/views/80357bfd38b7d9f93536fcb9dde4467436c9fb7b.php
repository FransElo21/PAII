

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mb-4">
    <!-- Other cards remain the same -->
    <div class="col-md-3">
        <div class="card text-center" style="height: 290px; background-color: white; border-radius: 15px; box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);">
            <div class="card-body">
                <div class="card-content display-4 font-weight-bold" style="font-size: 80px;">
                    <?php echo e($undangan_masuk); ?>

                </div>
                <p class="card-text" style="font-size: 15px;"><i class="fa-regular fa-calendar"></i> <span style="font-weight: bold;">Hari Ini</span></p>
                <div class="">
                    <i class="fa-solid fa-user cardb-icon" style="font-size: 20px;"></i>
                </div>
                <p class="card-text" style="font-size: 15px; "><span style="font-weight: bold;">Undangan Masuk</span></p>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#hostModal">Selengkapnya</button>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card text-center" style="height: 290px; background-color: white; border-radius: 15px; box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);">
            <div class="card-body">
                <div class="card-content display-4 font-weight-bold" style="font-size: 80px;">
                    <?php echo e($undangan_akan_datang); ?> 
                </div>
                <p class="card-text " style="font-size: 15px;"><i class="fa-regular fa-calendar"></i> <span style="font-weight: bold;">Hari Ini</span></p>
                <div class="">
                    <i class="fa-solid fa-user-group cardb-icon" style="font-size: 20px;"></i>
                </div>
                <p class="card-text" style="font-size: 15px; "><span style="font-weight: bold;">Yang Akan Datang</span></p>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#hostModal">Selengkapnya</button>
            </div>
        </div>
    </div>

    

    <div class="col-md-3">
        <div class="card text-center" style="height: 290px; background-color: white; border-radius: 15px; box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);">
            <div class="card-body">
                <div class="card-content display-4 font-weight-bold" style="font-size: 80px;">
                    <?php echo e($undangan_kadaluarsa); ?> 
                </div>
                <p class="card-text" style="font-size: 15px;"><i class="fa-regular fa-calendar"></i> <span style="font-weight: bold;">Hari Ini</span></p>
                <div class="">
                    <i class="fa-solid fa-user-slash cardb-icon" style="font-size: 20px;"></i>
                </div>
                <p class="card-text" style="font-size: 15px; "><span style="font-weight: bold;">Kadaluarsa</span></p>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#hostModal">Selengkapnya</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('host.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PAII\VMS\resources\views/host/berandahost.blade.php ENDPATH**/ ?>