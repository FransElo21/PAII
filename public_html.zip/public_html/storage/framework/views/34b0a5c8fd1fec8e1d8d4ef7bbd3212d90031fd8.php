

    <?php $__env->startSection('content'); ?>
    <style>
        .card {
            border-radius: 30px;
            box-shadow: 0 10px 16px rgba(0, 0, 0, 0.1);
        }

        .form-control {
            border-radius: 20px;
            border-color: #ccc;
        }

        .form-group h4 {
            margin-top: 20px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            border-radius: 20px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
            border-radius: 20px;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }

        .card-header {
            color: white;
            font-size: 25px;
            border-radius: 25px;
            padding: 20px 0;
            text-align: center;
        }

        .group-member {
            margin-bottom: 10px;
        }
    </style>
    <?php if(session('buat_undangan_berhasil')): ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success Membuat Undangan!',
                text: '<?php echo e(session('success_updatehost')); ?>',
            });
        </script>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container mt-5">
        <form action="<?php echo e(route('janji_temu.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-header" style="justify-content: center">
                    <h2 class="card-title mb-2" style="font-size:27px;"><b>Form Undangan</b></h2>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <input type="text" id="subject" name="subject" class="form-control" placeholder="Subject" required>
                        </div>
                        <div class="col-md-6">
                            <select name="keperluan" id="keperluan" class="form-control" required>
                                <option value="" disabled selected>Keperluan</option>
                                <option value="Pribadi">Pribadi</option>
                                <option value="Pekerjaan">Pekerjaan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <input type="text" id="kunjungan_dari" name="kunjungan_dari" class="form-control" placeholder="Kunjungan Dari" required>
                        </div>
                        <div class="col-md-6">
                            <select name="host_id" id="host_id" class="form-control custom-dropdown" required>
                                <option value="" disabled selected>Host</option>
                                <?php $__currentLoopData = $hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($host->id); ?>" data-nama="<?php echo e($host->nama); ?>" data-divisi="<?php echo e($host->divisi->nama_divisi); ?>" data-ruangan="<?php echo e($host->lokasi->ruangan); ?> <?php echo e($host->lokasi->lantai); ?>">
                                        <?php echo e($host->nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div id="host_details" style="display: none;">
                                <p>Host yang ingin diundang:</p>
                                <p><strong>Nama:</strong> <span id="host_nama">Frans Panjaitan</span></p>
                                <p><strong>Divisi:</strong> <span id="host_divisi">Divisi</span></p>
                                <p><strong>Ruangan:</strong> <span id="host_ruangan">Ruangan</span></p>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="waktu_temu" class="form-label">Waktu Temu</label>
                            <input type="datetime-local" id="waktu_temu" name="waktu_temu" class="form-control" placeholder="Waktu Temu" required>
                        </div>
                        <div class="col-md-6">
                            <label for="waktu_temu" class="form-label">Waktu Kembali</label>
                            <input type="datetime-local" id="waktu_kembali" name="waktu_kembali" class="form-control" placeholder="Waktu Kembali">
                        </div>
                        
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <input type="text" id="keterangan" name="keterangan" class="form-control" placeholder="Keterangan" required>
                        </div>
                        <div class="col-md-6">
                            <select name="type" id="type" class="form-control" required>
                                <option value="" disabled selected>Tipe</option>
                                <option value="personal">Personal</option>
                                <option value="group">Group</option>
                            </select>
                        </div>
                    </div>
                    <div id="groupMembers" style="display: none;">
                        <h4>Group Members</h4>
                        <div class="row mb-3 group-member">
                            <div class="col-md-2">
                                <input type="text" id="member_name" name="group_members[0][name]" class="form-control" placeholder="Name">
                            </div>
                            <div class="col-md-2">
                                <input type="email" id="member_email" name="group_members[0][email]" class="form-control" placeholder="Email">
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <input type="tel" class="form-control" id="phone" name="group_members[0][phone]" value="<?php echo e(old('nomor_telepon')); ?>" placeholder="Nomor Telepon" required>
                                    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
                                    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"></script>
                                    <script>
                                      document.addEventListener("DOMContentLoaded", function() {
                                        const phoneInputField = document.querySelector("#phone");
                                        const phoneInput = window.intlTelInput(phoneInputField, {
                                          utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
                                        });
                            
                                        phoneInputField.addEventListener("countrychange", function() {
                                          phoneInputField.value = '';
                                          const selectedCountryData = phoneInput.getSelectedCountryData();
                                          const countryCode = selectedCountryData.dialCode;
                                          let phoneNumber = phoneInput.getNumber();
                                          phoneNumber = phoneNumber.replace(/\D/g, '');
                                          if (!phoneNumber.startsWith(countryCode)) {
                                            phoneNumber = "+" + countryCode + phoneNumber;
                                            phoneInput.setNumber(phoneNumber);
                                          }
                                        });
                            
                                        function process(event) {
                                          event.preventDefault();
                                          const phoneNumber = phoneInput.getNumber();
                                          console.log("Phone Number:", phoneNumber);
                                        }
                                      });
                                    </script>
                                </div>
                            </div>                            
                            <div class="col-md-2">
                                <input type="text" id="member_nik" name="group_members[0][nik]" class="form-control" placeholder="NIK">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger remove-member">Remove</button>
                            </div>
                        </div>                        
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" id="addGroupMember" class="btn btn-secondary rounded-pill">Add Member</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer" style="text-align: center">
                    <button type="submit" class="btn btn-success rounded-pill">Submit</button>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
    $('#type').change(function () {
        if ($(this).val() === 'group') {
            $('#groupMembers').show();
            $('#groupMembers input').prop('required', true); // Set required fields
        } else {
            $('#groupMembers').hide();
            $('#groupMembers input').prop('required', false); // Unset required fields
        }
    });

    // Trigger change event on page load to ensure the correct state is set
    $('#type').trigger('change');

    let memberIndex = 1;
    $('#addGroupMember').click(function () {
        const newMember = $('.group-member:first').clone().removeAttr('id');
        newMember.find('input').each(function () {
            const name = $(this).attr('name');
            const newName = name.replace(/\[\d+\]/, `[${memberIndex}]`);
            $(this).attr('name', newName).val('');
        });

        newMember.insertBefore('#addGroupMember').show();

        // Initialize intl-tel-input for the new phone input
        const newPhoneInput = newMember.find('#phone');
        newPhoneInput.removeAttr('id'); // Remove the id attribute to avoid duplicates
        newPhoneInput.intlTelInput({
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
        });

        memberIndex++;
    });

    $(document).on('click', '.remove-member', function () {
        $(this).closest('.group-member').remove();
    });

    $('#host_id').change(function () {
        var selectedOption = $(this).children("option:selected");
        var nama = selectedOption.data('nama');
        var divisi = selectedOption.data('divisi');
        var ruangan = selectedOption.data('ruangan');
        
        // Menampilkan detail host di bawah dropdown
        $('#host_nama').text(nama);
        $('#host_divisi').text(divisi);
        $('#host_ruangan').text(ruangan);
        $('#host_details').show();
    });

    // Mengatur tanggal dan waktu minimum untuk input waktu_temu dan waktu_kembali
    var now = new Date().toISOString().slice(0, 16); // Format: YYYY-MM-DDTHH:mm
    $('#waktu_temu').attr('min', now);
    $('#waktu_kembali').attr('min', now);

    // Ketika pengguna memilih tanggal atau waktu pada input waktu_temu
    $('#waktu_temu').change(function () {
        // Mendapatkan nilai input
        var selectedDateTime = new Date($(this).val()).getTime();
        var nowDateTime = new Date().getTime();

        // Membandingkan dengan waktu saat ini
        if (selectedDateTime < nowDateTime) {
            alert('Waktu tidak dapat dipilih sebelum waktu saat ini.');
            $(this).val(now); // Kembalikan ke nilai minimum jika memilih waktu sebelum waktu saat ini
        }
    });

    // Ketika pengguna memilih tanggal atau waktu pada input waktu_kembali
    $('#waktu_kembali').change(function () {
        // Mendapatkan nilai input
        var selectedDateTime = new Date($(this).val()).getTime();
        var nowDateTime = new Date().getTime();

        // Membandingkan dengan waktu saat ini
        if (selectedDateTime < nowDateTime) {
            alert('Waktu tidak dapat dipilih sebelum waktu saat ini.');
            $(this).val(now); // Kembalikan ke nilai minimum jika memilih waktu sebelum waktu saat ini
        }
    });
});
</script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PAII\VMS - Copy\resources\views/buat_undangan.blade.php ENDPATH**/ ?>