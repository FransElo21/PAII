

<?php $__env->startSection('content'); ?>
    <title>Scan QR Code</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 mb-4">
                <div class="card h-100 shadow">
                    <div class="card-header">
                        <h1 class="card-title">Scan QR Code</h1>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between">
                        <div id="reader" style="width: 100%;"></div>
                        <input type="text" id="result" class="form-control mt-3" readonly hidden>
                    </div>
                </div>
            </div>
            <div class="col-md-8" id="qrDetailCard" style="display: none;">
                <div class="card h-100 shadow">
                    <div class="card-header">
                        <h3 class="card-title">Detail QR Code</h3>
                    </div>
                    <div class="card-body d-flex">
                        <div class="profile-img-wrapper me-3">
                            <a id="fotoProfilLink" href="" target="_blank">
                                <img id="qrFotoProfil" src="" alt="Foto Profil" class="img-thumbnail" style="width: 150px; height: 150px;">
                            </a>
                        </div>
                        <div>
                            <p><strong>Nama Lengkap:</strong> <span id="qrNama"></span></p>
                            <p><strong>Host:</strong> <span id="qrHost"></span></p>
                            <p><strong>Waktu Temu:</strong> <span id="qrWaktuTemu"></span></p>
                            <p><strong>Waktu Kembali:</strong> <span id="qrWaktuKembali"></span></p>
                            <p><strong>Lokasi :</strong> <span id="qrLokasi"></span></p>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between">
                        <button id="rejectBtn" class="btn btn-danger">Tolak</button>
                        <button id="acceptBtn" class="btn btn-success">Terima</button>
                    </div>
                </div>                
            </div>
        </div>
    </div>

    <script>
        let previousQrCode = null;

        function onScanSuccess(decodedText, decodedResult) {
            console.log("Decoded Text: ", decodedText);
            if (decodedText !== previousQrCode) {
                $('#result').val(decodedText);

                // Assuming decodedText is JSON string
                try {
                    const qrData = JSON.parse(decodedText);
                    console.log("QR Data: ", qrData);
                    $('#qrNama').text(qrData.Nama);
                    $('#qrHost').text(qrData.Host);
                    $('#qrWaktuTemu').text(qrData['Waktu Temu']);
                    $('#qrWaktuKembali').text(qrData['Waktu Kembali']);
                    $('#qrLokasi').text(qrData.Lokasi);

                    const fotoProfilUrl = qrData['Foto Profil']; // Example URL: /foto_profile_user/profile1.jpg
                    console.log("Foto Profil URL: ", fotoProfilUrl);

                    // Set image source and link URL
                    $('#qrFotoProfil').attr('src', fotoProfilUrl);
                    $('#fotoProfilLink').attr('href', fotoProfilUrl);

                    $('#qrDetailCard').show();  // Show detail card after successful scan
                } catch (error) {
                    console.error("QR code data is not in the expected format:", error);
                    return;
                }

                previousQrCode = decodedText;
            }
        }

        function onScanFailure(error) {
            console.warn(`QR error = ${error}`);
        }

        $(document).ready(function() {
            let html5QrcodeScanner = new Html5QrcodeScanner(
                "reader",
                { fps: 30, qrbox: { width: 250, height: 250 } },
                false
            );

            function resetScanner() {
                html5QrcodeScanner.clear().then(() => {
                    html5QrcodeScanner.render(onScanSuccess, onScanFailure);
                }).catch(error => {
                    console.error('Failed to reset QR scanner: ', error);
                });
            }

            function clearQrDetails() {
                $('#result').val('');
                $('#qrNama').text('');
                $('#qrHost').text('');
                $('#qrWaktuTemu').text('');
                $('#qrWaktuKembali').text('');
                $('#qrFotoProfil').attr('src', '');
                $('#fotoProfilLink').attr('href', '');
                $('#qrDetailCard').hide();  // Hide detail card when rejected
                previousQrCode = null;
            }

            html5QrcodeScanner.render(onScanSuccess, onScanFailure);

            $('#acceptBtn').on('click', function() {
                const qrCode = $('#result').val();
                $.ajax({
                    url: '/scan_qr_code',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        qr_code: qrCode
                    },
                    success: function (response) {
                        console.log(response);
                        Swal.fire({
                            icon: response.status == 200 ? 'success' : 'error',
                            title: response.message,
                            confirmButtonText: 'Oke', 
                            confirmButtonColor: "#0265F3"
                        }).then(() => {
                            clearQrDetails();
                            resetScanner();
                        });
                    },
                    error: function (xhr, status, error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Terjadi kesalahan',
                            text: 'Silakan coba lagi nanti.',
                            confirmButtonText: 'Oke',
                            confirmButtonColor: "#0265F3"
                        }).then(() => {
                            resetScanner();
                        });
                    }
                });
            });

            $('#rejectBtn').on('click', function() {
                clearQrDetails();
                Swal.fire({
                    icon: 'info',
                    title: 'Pemindaian QR code ditolak',
                    confirmButtonText: 'Oke',
                    confirmButtonColor: "#0265F3"
                }).then(() => {
                    resetScanner();
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('entry_point.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pp\Terbaru\public_html\resources\views/entry_point/checkin_out.blade.php ENDPATH**/ ?>