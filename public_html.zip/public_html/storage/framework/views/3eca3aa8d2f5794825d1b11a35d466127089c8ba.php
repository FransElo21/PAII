

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header" style="font-size: 25px; color:black;">Informasi Kunjungan</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item" style="padding: 5px 0;">Jam Operasional Kunjungan
                                        <p style="margin: 5px 0;">08.00 - 17.00</p>
                                    </li>
                                    <li class="list-group-item" style="padding: 5px 0;">Hari Operasional Kunjungan
                                        <p style="margin: 5px 0;">Senin - Jumat</p>
                                    </li>
                                    <li class="list-group-item" style="padding: 5px 0;">Informasi Kunjungan
                                        <p style="margin: 5px 0;">10 Lantai</p>
                                    </li>
                                    <li class="list-group-item" style="padding: 5px 0;">Alamat
                                        <p style="margin: 5px 0;">Depan gerbang Institut Teknologi Del, Sitoluama, Kec. Balige, Toba, Sumatera Utara 22381</p>
                                    </li>
                                    <li class="list-group-item" style="padding: 5px 0;">catatan
                                        <p style="margin: 5px 0;">Dapat bertanya pada resepsionis atau satpam jika mengalami kesulitan</p>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h5 class="card-title"></h5>
                                <!-- Google Map Embed -->
                                <iframe 
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.071186947819!2d-122.08424968468197!3d37.422065779821534!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808fb5e0f6a7d0c1%3A0x57cd7750d55e1b58!2sGoogleplex!5e0!3m2!1sen!2sus!4v1596809195632!5m2!1sen!2sus" 
                                    width="100%" 
                                    height="300" 
                                    frameborder="0" 
                                    style="border:0; margin-top: 10px;" 
                                    allowfullscreen="" 
                                    aria-hidden="false" 
                                    tabindex="0">
                                </iframe>
                                <a href="https://www.google.com/maps" class="btn btn-primary mt-3">Lihat Peta</a>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-muted">
                        <!-- Additional footer content can go here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MATA KULIAH\Semester 4\PA2\New folder (2)\VMS\resources\views/lokasi.blade.php ENDPATH**/ ?>