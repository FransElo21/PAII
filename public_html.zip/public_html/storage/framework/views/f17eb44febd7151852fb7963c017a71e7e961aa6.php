<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Undangan</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Riwayat Undangan</h2>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Lengkap</th>
                <th>Kunjungan Dari</th>
                <th>Host</th>
                <th>Subjek</th>
                <th>Waktu Bertemu</th>
                <th>Waktu Kembali</th>
                <th>Lokasi</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1 ?>
            <?php $__currentLoopData = $undangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($item->pengunjung->namaLengkap); ?></td>
                <td><?php echo e($item->kunjungan_dari); ?></td>
                <td><?php echo e($item->host->nama); ?></td>
                <td><?php echo e($item->subject); ?></td>
                <td><?php echo e($item->waktu_temu); ?></td>
                <td><?php echo e($item->waktu_kembali); ?></td>
                <td><?php echo e($item->lokasi->ruangan); ?> <?php echo e($item->lokasi->lantai); ?></td>
                <td><?php echo e($item->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\PAII\VMS - Copy\resources\views/admin/cetak.blade.php ENDPATH**/ ?>