

<?php $__env->startSection('content'); ?>

<?php if(session('custom_success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('custom_success')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<style>
    .btn-custom-blue {
        background-color: #007bff; /* Warna biru */
        color: white;
        border: none;
    }

    .btn-custom-blue:hover {
        background-color: #0056b3; /* Warna biru lebih gelap untuk efek hover */
    }

    .profile-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .profile-image {
        width: 120px;
        height: 120px;
        margin-bottom: 20px;
    }

    .profile-details {
        width: 100%;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .card-header {
        background-color: #355283;
        color: white;
        font-size: 20px;
        text-align: center;
    }

    .card-body {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .form-control-plaintext {
        text-align: center;
        color: #333;
        font-weight: bold;
        font-size: 16px;
    }

    .button-group {
        display: flex;
        width: 100%;
        justify-content: space-between;
        margin-top: 20px;
    }

    .btn-xl {
        padding: 10px 20px;
        font-size: 16px;
    }

</style>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header"><?php echo e(__('Entry Point Profile')); ?></div>
                <div class="card-body">
                    <div class="profile-container">
                        <img src="<?php echo e(asset('images/profile/pic1.jpg')); ?>" class="rounded-circle profile-image" alt="Profile Picture">
                        <div class="profile-details">
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>
                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control-plaintext" name="name" value="<?php echo e($Entry->nama); ?>" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Username')); ?></label>
                                <div class="col-md-6">
                                    <input id="username" type="text" class="form-control-plaintext" name="username" value="<?php echo e($Entry->username); ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="button-group">
                        <a href="#" class="btn btn-custom-blue btn-xl" data-bs-toggle="modal" data-bs-target="#modalChangePassword">Ganti Password</a>
                        <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger btn-xl">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Change Password -->
<div class="modal fade" id="modalChangePassword" tabindex="-1" aria-labelledby="modalChangePasswordLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="modalChangePasswordLabel"><b>Ganti Password</b></h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="<?php echo e(route('Entrypoint.update_password')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group row">
                        <label for="current_password" class="col-md-4 col-form-label text-md-right">Password Sekarang</label>
                        <div class="col-md-6">
                            <input id="current_password" type="password" class="form-control" name="current_password" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="new_password" class="col-md-4 col-form-label text-md-right">Password Baru</label>
                        <div class="col-md-6">
                            <input id="new_password" type="password" class="form-control" name="new_password" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="new_password_confirmation" class="col-md-4 col-form-label text-md-right">Konfirmasi Password Baru</label>
                        <div class="col-md-6">
                            <input id="new_password_confirmation" type="password" class="form-control" name="new_password_confirmation" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('entry_point.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u626304679/domains/mediumvioletred-dogfish-273295.hostingersite.com/public_html/resources/views/entry_point/profile_entrypoint.blade.php ENDPATH**/ ?>