

<?php $__env->startSection('content'); ?>
    <title>Scan QR Code</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 mb-4">
                <div class="card h-100 shadow">
                    <div class="card-header">
                        <h1 class="card-title">Scan QR Code</h1>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between">
                        <div id="reader" style="width: 100%;"></div>
                        <input type="text" id="result" class="form-control mt-3" readonly hidden>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card h-100 shadow">
                    <div class="card-header">
                        <h3 class="card-title">Detail QR Code</h3>
                    </div>
                    <div class="card-body d-flex">
                        <div class="profile-img-wrapper me-3">
                            <img id="qrFotoProfil" src="" alt="Foto Profil" class="img-thumbnail" style="width: 150px; height: 150px;">
                        </div>
                        <div>
                            <p><strong>Nama:</strong> <span id="qrNama"></span></p>
                            <p><strong>Host:</strong> <span id="qrHost"></span></p>
                            <p><strong>Waktu Temu:</strong> <span id="qrWaktuTemu"></span></p>
                            <p><strong>Waktu Kembali:</strong> <span id="qrWaktuKembali"></span></p>
                            <div class="d-flex justify-content-end mt-3">
                                <button id="acceptBtn" class="btn btn-success me-2">Terima</button>
                                <button id="rejectBtn" class="btn btn-danger">Tolak</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let previousQrCode = null;

        function onScanSuccess(decodedText, decodedResult) {
            console.log("Decoded Text: ", decodedText);
            if (decodedText !== previousQrCode) {
                $('#result').val(decodedText);

                // Assuming decodedText is JSON string
                try {
                    const qrData = JSON.parse(decodedText);
                    console.log("QR Data: ", qrData);
                    $('#qrNama').text(qrData.Nama);
                    $('#qrHost').text(qrData.Host);
                    $('#qrWaktuTemu').text(qrData['Waktu Temu']);
                    $('#qrWaktuKembali').text(qrData['Waktu Kembali']);
                    
                    const fotoProfilUrl = qrData['Foto Profil'];
                    console.log("Foto Profil URL: ", fotoProfilUrl);
                    $('#qrFotoProfil').attr('src', fotoProfilUrl);
                    
                    $('#qrData').show();
                } catch (error) {
                    console.error("QR code data is not in the expected format:", error);
                    return;
                }

                previousQrCode = decodedText;
            }
        }

        function onScanFailure(error) {
            console.warn(`QR error = ${error}`);
        }

        $(document).ready(function() {
    html5QrcodeScanner = new Html5QrcodeScanner(
        "reader",
        { fps: 30, qrbox: { width: 250, height: 250 } },
        false
    );
    html5QrcodeScanner.render(onScanSuccess, onScanFailure);

    $('#acceptBtn').on('click', function() {
        const qrCode = $('#result').val();
        $.ajax({
            url: '/scan_qr_code',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                qr_code: qrCode
            },
            success: function (response) {
                console.log(response);
                if (response.status == 200) {
                    Swal.fire({
                        icon: 'success',
                        title: 'QR code valid',
                        showConfirmButton: false,
                        timer: 1500
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'QR code tidak valid',
                        showConfirmButton: false,
                        timer: 1500
                    });
                }
            },
            error: function (xhr, status, error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Terjadi kesalahan',
                    text: 'Silakan coba lagi nanti.',
                });
            }
        });
    });

    $('#rejectBtn').on('click', function() {
        $('#result').val('');
        $('#qrNama').text('');
        $('#qrHost').text('');
        $('#qrWaktuTemu').text('');
        $('#qrWaktuKembali').text('');
        $('#qrFotoProfil').attr('src', '');
        $('#qrData').hide();
        previousQrCode = null;
        Swal.fire({
            icon: 'info',
            title: 'Pemindaian QR code ditolak',
            showConfirmButton: false,
            timer: 1500
        });
    });
});

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('entry_point.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u626304679/domains/mediumvioletred-dogfish-273295.hostingersite.com/public_html/resources/views/entry_point/checkin_out.blade.php ENDPATH**/ ?>