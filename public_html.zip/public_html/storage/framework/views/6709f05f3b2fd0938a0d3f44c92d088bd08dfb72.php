

<?php $__env->startSection('content'); ?>
    <title>Scan QR Code</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card h-100 shadow">
                    <div class="card-header">
                        <h1 class="card-title">Scan QR Code</h1>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between">
                        <div id="reader"></div>
                        <input type="text" id="result" class="form-control mt-3" readonly>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let html5QrcodeScanner;
        let previousQrCode = null;

        function onScanSuccess(decodedText, decodedResult) {
            // Periksa apakah QR code yang dipindai berbeda dengan sebelumnya
            if (decodedText !== previousQrCode) {
                // Tampilkan data QR code yang dipindai
                $('#result').val(decodedText);

                // Buat permintaan AJAX POST ke controller
                $.ajax({
                    url: '/scan_qr_code',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        qr_code: decodedText
                    },
                    success: function (response) {
                        console.log(response);
                        if (response.status == 200) {
                            alert('QR code valid');
                            // console.log("QR Code Data:", response.qrCodeData);
                        } else {
                            alert('QR code tidak valid');
                        }
                    },
                    error: function (xhr, status, error) {
                        alert('Terjadi kesalahan');
                    }
                });

                // Simpan QR code yang baru dipindai
                previousQrCode = decodedText;
            }
        }

        function onScanFailure(error) {
            // Tangani kesalahan saat pemindaian QR code
        }

        $(document).ready(function() {
            navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 400, height: 400 } })
                .then(stream => {
                    html5QrcodeScanner = new Html5QrcodeScanner(
                        "reader",
                        { fps: 30, qrbox: { width: 400, height: 400 } },
                        /* verbose= */ false
                    );
                    html5QrcodeScanner.render(onScanSuccess, onScanFailure, stream);
                })
                .catch(error => {
                    console.error('Error accessing camera:', error);
                });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('entry_point.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pp\public_html\resources\views/entry_point/checkin_out.blade.php ENDPATH**/ ?>