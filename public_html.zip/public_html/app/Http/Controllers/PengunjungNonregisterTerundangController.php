<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PengunjungNonregisterTerundangController extends Controller
{
    protected $table = 'pengunjung_nonregister_terundang';
    protected $guarded = [];
}
