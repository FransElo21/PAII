<?php

namespace App\Http\Controllers;

use App\Models\Divisi;
use DateTimeZone;
use App\Models\Pengunjung;
use App\Models\GroupMember;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\UndanganPengunjung;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\logs_undangan_pengunjung;
use App\Models\pengunjung_undangan_host;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class EntryPointController extends Controller
{
    // public function index_entrypoint()
    // {
    //     $title = "Beranda";
    //     return view('entry_point.berandaentrypoint', compact('title'));
    // }

    public function index_entrypoint(){
        // Semua kunjungan
        $today = Carbon::now('Asia/Jakarta');

        $datasemua_kunjungan = UndanganPengunjung::whereDate('waktu_temu', $today)->get();
        $yang_akan_datang = UndanganPengunjung::whereDate('waktu_temu', $today)->where('status', 'Diterima')->get();
        $kadaluarsa = UndanganPengunjung::whereDate('waktu_temu', $today)->where('status', 'Kadaluarsa')->get();

        $semua_kunjungan = UndanganPengunjung::whereDate('waktu_temu', $today)->count();

        $recentUsers = Pengunjung::orderBy('last_login', 'desc')->take(5)->get();
    
        // Kunjungan yang akan datang hari ini (status = diterima dan waktu_temu = hari ini)
        $kunjungan_hari_ini = UndanganPengunjung::where('status', 'diterima')
            ->whereDate('waktu_temu', Carbon::today())
            ->count();


            $today = now()->toDateString();

            // Menghitung jumlah pengunjung yang mendaftar dengan check_in dan check_out yang berisi
            $logs_kunjungan_check_in_out = logs_undangan_pengunjung::whereHas('undangan_pengunjung', function ($query) use ($today) {
                $query->whereDate('waktu_kembali', $today)->whereNotNull('check_in')->whereNotNull('check_out');
            })->count();
            
            // Menghitung jumlah anggota grup yang diundang dengan check_in dan check_out yang berisi
            $groupMember_kunjungan_check_in_out = GroupMember::whereHas('undangan', function ($query) use ($today) {
                $query->whereDate('waktu_kembali', $today)->whereNotNull('check_in')->whereNotNull('check_out');
            })->count();
            
            // Menghitung jumlah host pengunjung yang diundang dengan check_in dan check_out yang berisi
            $hostKunjungan_check_in_out = pengunjung_undangan_host::whereHas('undanganHost', function ($query) use ($today) {
                $query->whereDate('waktu_kembali', $today)->whereNotNull('check_in')->whereNotNull('check_out');
            })->count();
            
            // Menggabungkan jumlah dari semua data
            $total_kunjungan_check_in_out = $logs_kunjungan_check_in_out + $groupMember_kunjungan_check_in_out + $hostKunjungan_check_in_out;            
            

    
        // Kunjungan yang kadaluarsa (status = kadaluarsa)
        $kunjungan_kadaluarsa = UndanganPengunjung::where('status', 'kadaluarsa')
            ->whereDate('waktu_temu', $today)
            ->count();

            $today = now()->toDateString();

            // Menyiapkan data untuk pengunjung yang mendaftar
            $registers = logs_undangan_pengunjung::whereHas('undangan_pengunjung', function ($query) use ($today) {
                $query->whereDate('waktu_kembali', $today);
            })->get()->map(function($register) {
                return [
                    'id' => $register->id,
                    'name' => $register->pengunjung->namaLengkap,
                    'check_in' => $register->check_in,
                    'check_out' => $register->check_out,
                    'waktu_temu' => $register->undangan_pengunjung->waktu_temu,
                    'waktu_kembali' => $register->undangan_pengunjung->waktu_kembali,
                    'subject' => $register->undangan_pengunjung->subject,
                    'status' => $register->undangan_pengunjung->status,
                    'Host' => $register->undangan_pengunjung->host->nama
                ];
            })->filter(function($register) {
                return $register['check_in'] || $register['check_out'];
            });
            
            // Menyiapkan data untuk anggota grup yang diundang
            $nonRegisters = GroupMember::whereHas('undangan', function ($query) use ($today) {
                $query->whereDate('waktu_kembali', $today);
            })->get()->map(function($nonRegister) {
                return [
                    'id' => $nonRegister->id,
                    'name' => $nonRegister->name,
                    'check_in' => $nonRegister->check_in,
                    'check_out' => $nonRegister->check_out,
                    'waktu_temu' => $nonRegister->undangan->waktu_temu,
                    'waktu_kembali' => $nonRegister->undangan->waktu_kembali,
                    'subject' => $nonRegister->undangan->subject,
                    'status' => $nonRegister->undangan->status,
                    'Host' => $nonRegister->undangan->host->nama
                ];
            })->filter(function($nonRegister) {
                return $nonRegister['check_in'] || $nonRegister['check_out'];
            });
            
            // Menyiapkan data untuk host pengunjung yang diundang
            $hostRegisters = pengunjung_undangan_host::whereHas('undanganHost', function ($query) use ($today) {
                $query->whereDate('waktu_kembali', $today);
            })->get()->map(function($hostRegister) {
                return [
                    'id' => $hostRegister->id,
                    'name' => $hostRegister->nama,
                    'check_in' => $hostRegister->waktu_temu,
                    'check_out' => $hostRegister->waktu_kembali,
                    'waktu_temu' => $hostRegister->undanganHost->waktu_temu,
                    'waktu_kembali' => $hostRegister->undanganHost->waktu_kembali,
                    'subject' => $hostRegister->undanganHost->subject,
                    'status' => $hostRegister->undanganHost->status,
                    'Host' => $hostRegister->undanganHost->host->nama
                ];
            })->filter(function($hostRegister) {
                return $hostRegister['check_in'] || $hostRegister['check_out'];
            });
            
            // Menggabungkan semua data menjadi satu
        $combinedData = $registers->merge($nonRegisters)->merge($hostRegisters);
    
        return view('entry_point.berandaentrypoint', compact('semua_kunjungan', 'kunjungan_hari_ini', 'kunjungan_kadaluarsa' ,'recentUsers', 'total_kunjungan_check_in_out', 'datasemua_kunjungan', 'combinedData','yang_akan_datang', 'kadaluarsa'));
    }
    
    
    public function scanQrCode(Request $request)
{
    try {
        // Mendapatkan data QR code yang dipindai dari permintaan (request)
        $qrCodeData = json_decode($request->input('qr_code'), true);

        // Memastikan $qrCodeData tidak null dan memiliki kunci yang diperlukan
        if (!is_null($qrCodeData) && isset($qrCodeData['ID']) && isset($qrCodeData['Nama']) && isset($qrCodeData['participant_id'])) {
            // Logging informasi data QR code
            Log::info('QR Code Data: ' . print_r($qrCodeData, true));

            // Mencocokkan data QR code dengan data dalam database logs_undangan_pengunjung
            $matchingData = logs_undangan_pengunjung::where('undangan_id', $qrCodeData['ID'])
                ->where('pengunjung_id', $qrCodeData['participant_id'])
                ->first();

            // Jika data cocok ditemukan di logs_undangan_pengunjung
            if ($matchingData) {
                // Jika check_in dan check_out sudah ada, berikan respons error
                if ($matchingData->check_in && $matchingData->check_out) {
                    // Mengupdate status undangan menjadi 'Selesai' jika semua check_in dan check_out sudah terisi
                    if ($this->checkAllCompleted($qrCodeData['ID'])) {
                        $undangan = UndanganPengunjung::find($qrCodeData['ID']);
                        $undangan->status = 'Selesai';
                        $undangan->save();
                    }
                    return response()->json(['status' => 400, 'message' => 'QR code sudah terpakai']);
                } // Jika check_in sudah ada, update check_out
                elseif ($matchingData->check_in) {
                    $matchingData->update([
                        'check_out' => Carbon::now(new DateTimeZone('Asia/Jakarta')),
                    ]);
                    return response()->json(['status' => 200, 'message' => 'QR code valid - Check-out berhasil']);
                } // Jika check_in belum ada, update check_in
                else {
                    $matchingData->update([
                        'check_in' => Carbon::now(new DateTimeZone('Asia/Jakarta')),
                    ]);
                    return response()->json(['status' => 200, 'message' => 'QR code valid - Check-in berhasil']);
                }
            } else {
                return response()->json(['status' => 400, 'message' => 'Data QR code tidak cocok']);
            }
        } else {
            // Memberikan respons error jika data QR code tidak lengkap atau tidak valid
            return response()->json(['status' => 400, 'message' => 'Data QR code tidak lengkap atau tidak valid']);
        }
    } catch (\Exception $e) {
        // Logging informasi kesalahan yang terjadi
        Log::error('Error in scanQrCode: ' . $e->getMessage());

        // Memberikan respons error jika terjadi kesalahan
        return response()->json(['status' => 500, 'message' => 'Terjadi kesalahan.']);
    }
}

private function checkAllCompleted($undanganId)
{
    // Memeriksa apakah semua entri dalam logs_undangan_pengunjung untuk undangan tertentu sudah memiliki check_in dan check_out
    $allCompleted = logs_undangan_pengunjung::where('undangan_id', $undanganId)
        ->whereNull('check_out')
        ->doesntExist();

    return $allCompleted;
}




    public function index_scanQrCode(){
        return view('entry_point/checkin_out');
    }

    public function index_riwayat(){
        $undangan = UndanganPengunjung::whereIn('status', ['Ditolak', 'Kadaluarsa', 'Selesai'])->get();
        return view('entry_point/riwayatEP', compact('undangan'));
    }

    public function index_IT(){
        $undangan = UndanganPengunjung::where('status', 'Diterima')->with('divisi')->get();
        $divisis = Divisi::all();
        return view('entry_point/informasitamuEP', compact('undangan','divisis'));
    }

    public function index_profile_entry(){

        $Entry = Auth::guard('entry_point')->user();

        return view('entry_point.profile_entrypoint', compact('Entry'));
    }

    public function editPasswordForm()
    {
        return view('entry_point.edit_password');
    }

    public function updatePassword(Request $request)
{
    $entry_point = Auth::guard('entry_point')->user(); // Mengambil admin yang sedang login

    // Validasi input
    $request->validate([
        'current_password' => 'required',
        'new_password' => 'required|string|min:8|different:current_password',
        'new_password_confirmation' => 'same:new_password',
    ]);

    // Periksa apakah password saat ini sesuai
    if (!Hash::check($request->current_password, $entry_point->password)) {
        return back()->withErrors(['current_password' => 'The current password is incorrect.']);
    }

    // Hash password baru
    $entry_point->password = Hash::make($request->new_password);

    // Simpan perubahan
    $entry_point->save();

    // Simpan pesan sukses ke dalam session
    session()->flash('custom_success', 'Password Berhasil Diperbaharui.');
    return redirect()->route('profile_entry.show')->with('success', 'Password Berhasil Diperbaharui.');
}

    
}
